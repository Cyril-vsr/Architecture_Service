package com.example.windowservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WindowserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
